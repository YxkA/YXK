package com.google.spring.aop.concert;

public interface Performance {
    void perform();
}
