package com.google.spring.aop.concert;

import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class Audience {
    @Before("execution(* com.google.spring.aop.concert.Performance.perform(..))")
    public void silenceCellPhones() {
        System.out.println("Silencing cell phones");
    }

    @Before("execution(* com.google.spring.aop.concert.Performance.perform(..))")
    public void takeSeats() {
        System.out.println("The audience is taking their seats.");
    }

    @AfterReturning("execution(* com.google.spring.aop.concert.Performance.perform(..))")
    public void applaud() {
        System.out.println("CLAP CLAP CLAP CLAP CLAP");
    }

    @AfterThrowing("execution(* com.google.spring.aop.concert.Performance.perform(..))")
    public void demandRefund() {
        System.out.println("Boo! We want our money back!");
    }
}
